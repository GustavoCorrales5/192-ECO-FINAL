var firebaseConfig = {
  apiKey: "AIzaSyDiUCdeucd0xGEjzxajFznO00SfEhoLuTU",
  authDomain: "chats14-e92f1.firebaseapp.com",
  databaseURL: "https://chats14-e92f1.firebaseio.com",
  projectId: "chats14-e92f1",
  storageBucket: "chats14-e92f1.appspot.com",
  messagingSenderId: "776588621525",
  appId: "1:776588621525:web:c46d86c5b8e284f901545c"
};
var firebase;

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

var usuario;



var submit =document.querySelector('.box__submit');
var code = document.querySelector('.box__codigo');
var contra = document.querySelector('.box__contrasena');

submit.addEventListener("click",function(event){
  event.preventDefault();
  
  var codeS=code.value; 
  var contraS=contra.value;
  
  console.log(codeS+" "+contra);
  
  
  acreditarInicio(codeS,contraS);
  
  
});

function acreditarInicio( codigo, pasword2){
  console.log('ENTRE A AUTENTICAR');
  var referenciaUsuarios = firebase.database().ref('users/');
  
  referenciaUsuarios.child(codigo).once("value",snapshot => {
    if (snapshot.exists()){
      const userData = snapshot.val();
      
      if(userData.pasword==pasword2){
        
        usuario=userData;
        console.log(usuario.nombre);
        window.location.href = '/views/home.html'  +'#'+ usuario.nombre+"/"+usuario.estatus;
      }else{
        alert("USUARIO NO EXISTENTE");
      }
      
      
    } else{
      alert("USUARIO NO EXISTENTE");
      
    }
    
    
  });
  
  
}


var inicio=document.querySelector('.nav__user');

inicio.addEventListener("click",function(event){
    window.location.href = '/views/home.html';
})


