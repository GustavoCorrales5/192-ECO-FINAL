var submit =document.querySelector('.box__submit');
var code = document.querySelector('.box__codigo');
var contra = document.querySelector('.box__contrasena');

submit.addEventListener("click",function(event){
    event.preventDefault();

    var codeS=code.value; 
    var contra=code.value;

    console.log(codeS+" "+contra);

    window.location.href = "/views/home.html";

})

