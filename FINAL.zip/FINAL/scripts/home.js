var nombreNav= document.querySelector('.data__nombre');
var statusNav= document.querySelector('.data__status');

var text = window.location.hash.substring(1);
console.log(usuario);
var queries = text.split("/");

    nombreNav.innerHTML=usuario.nombre;
    statusNav.innerHTML=usuario.estatus;



