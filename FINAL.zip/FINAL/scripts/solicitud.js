var inicio=document.querySelector('.nav__user');

inicio.addEventListener("click",function(event){
    window.location.href = '/views/home.html';
})


var enviarSolicitud= document.querySelector('.solicitud_pedido');
var fecha= document.querySelector('.solicitud__fecha');
var horaInicio= document.querySelector('.horaInicio');
var horaFinal= document.querySelector('.horaFin');
var elemento= document.querySelector('.elementos');

enviarSolicitud.addEventListener("click",function(event){
    event.preventDefault();
    var fechaS=fecha.value;
    var horaInicioS=horaInicio.value;
    var horaFinalS=horaFinal.value;
    var elementoS=elemento.value;
    console.log(fechaS+"/"+horaInicioS+"/"+horaFinalS+"/"+elementoS);
    var referenciaPedidos = firebase.database().ref('pedidos/');
    var id= referenciaPedidos.push().getKey();

    referenciaPedidos.child(fechaS).once("value",snapshot => {
        if (snapshot.exists()){
            const userData = snapshot.val();
            console.log(userData);
            if(horaInicioS>userData.horaInicio && horaInicioS<userData.horaFinal){
                console.log("tiempo ocupado");
                alert("tiempo ocupado");
            }
            else{
                firebase.database().ref('pedidos/' + fechaS).child(id).set({
                    fecha: fechaS,
                    horaInicio: horaInicioS,
                    horaFinal : horaFinalS,
                    elementos: elementoS,
                    ID: "A00012136"
                });       
                
                alert("solicitud creada con éxito");
         
            }
            
        } else{
            
            firebase.database().ref('pedidos/' + fechaS).child(id).set({
                fecha: fechaS,
                horaInicio: horaInicioS,
                horaFinal : horaFinalS,
                elementos: elementoS,
                ID: "A00012136"
            });   
            
            
            alert("solicitud creada con éxito");
        }
    });
    
});

