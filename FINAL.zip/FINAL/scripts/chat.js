var texto=document.querySelector('.chat__mensajeUsuario');

var enviar=document.querySelector('.chat__enviar');

var referenciaChat = firebase.database().ref('chat');
var id= "A00012136";
enviar.addEventListener("click",function(event){
    event.preventDefault();
    
    firebase.database().ref('chat').push().set({
        
        remitente: id, 
        mensaje: texto.value,
        
    });
    
});
var listaMensajes=document.querySelector('.mensajes');



referenciaChat.on("child_added", function(snapshot){
    
    console.log("El juego actual es ", snapshot.val());
    var data=snapshot.val();
    let listItem = document.createElement("div");
    listItem.innerHTML =
    "<div class=\"chat__msg\">"+
    ""+"<p class=\"msg\">"+data.remitente+":</p><br><p class=\"msg__content\">"+data.mensaje+"</p><br></div>";
    listaMensajes.appendChild(listItem);    
});

var inicio=document.querySelector('.nav__user');

inicio.addEventListener("click",function(event){
    window.location.href = '/views/home.html';
})

