package com.example.appusuariofinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class prestamoSonido extends AppCompatActivity {

    private ImageButton todo,fotografia,pantallas,prestamodevolver, home, chat, verElementos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prestamo_sonidp);

        todo = findViewById(R.id.todoboton5);
        fotografia = findViewById(R.id.fotoboton5);
        pantallas = findViewById(R.id.pantallaboton5);
        prestamodevolver = findViewById(R.id.prestamodevolver5);
        chat = findViewById(R.id.chatprestamo5);
        home = findViewById(R.id.homeboton5);
        verElementos = findViewById(R.id.verelementos_Todo3);

        //BOTONES NAVEGACION LOCAL ARRIBA
        prestamodevolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),inicio.class);
                startActivity(i);
            }
        });

        todo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),prestamoTodos.class);
                startActivity(i);
            }
        });
        fotografia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),prestamoFotografia.class);
                startActivity(i);
            }
        });

        pantallas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),prestamoPantalla.class);
                startActivity(i);
            }
        });

        //BOTONES BARRA DE NAVEGACION ABAJO

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),inicio.class);
                startActivity(i);
            }
        });


        chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),chats.class);
                startActivity(i);
            }
        });
    }
}
