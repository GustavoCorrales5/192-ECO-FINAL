package com.example.appusuariofinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class ayudaPantalla extends AppCompatActivity {

    private ImageButton todo,fotografia,sonido,ayudadevolver, home,chat,prestamo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ayuda_pantalla);

        todo = findViewById(R.id.todoAyudaPantalla);
        sonido = findViewById(R.id.sonidopantalla);
        fotografia = findViewById(R.id.fotografiapantalla);
        ayudadevolver = findViewById(R.id.ayudadevolverPantalla);

        chat = findViewById(R.id.chatAyudaPantalla);
        prestamo = findViewById(R.id.userayudpantalla);
        home = findViewById(R.id.homeayudapantalla);

        //BOTONES NAVEGACION ABAJO

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),inicio.class);
                startActivity(i);
            }
        });
        prestamo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),prestamos.class);
                startActivity(i);
            }
        });
        chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),chats.class);
                startActivity(i);
            }
        });

        //BOTONES NAVEGACION ARRIBA

        ayudadevolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),inicio.class);
                startActivity(i);
            }
        });

        todo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),ayudas.class);
                startActivity(i);
            }
        });
        sonido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),ayudaSonido.class);
                startActivity(i);
            }
        });
        fotografia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),ayudaFotografia.class);
                startActivity(i);
            }
        });
    }
}
