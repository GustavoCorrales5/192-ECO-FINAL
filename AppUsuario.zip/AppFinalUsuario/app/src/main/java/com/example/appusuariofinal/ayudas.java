package com.example.appusuariofinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class ayudas extends AppCompatActivity {

    private ImageButton fotografia,sonido,pantallas,ayudadevolver, home,chat,prestamo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ayudas);

        fotografia = findViewById(R.id.fotografiaAyuda);
        sonido = findViewById(R.id.sonidoAyuda);
        pantallas = findViewById(R.id.pantallaAyuda);
        ayudadevolver = findViewById(R.id.ayudadevolver);

        chat = findViewById(R.id.chatAyuda);
        prestamo = findViewById(R.id.userayuda);
        home = findViewById(R.id.homeayuda);

        //BOTONES NAVEGACION ABAJO

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),inicio.class);
                startActivity(i);
            }
        });
        prestamo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),prestamos.class);
                startActivity(i);
            }
        });
        chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),chats.class);
                startActivity(i);
            }
        });

        //BOTONES NAVEGACION ARRIBA

        ayudadevolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),inicio.class);
                startActivity(i);
            }
        });

        fotografia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),ayudaFotografia.class);
                startActivity(i);
            }
        });
        sonido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),ayudaSonido.class);
                startActivity(i);
            }
        });
        pantallas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),ayudaPantalla.class);
                startActivity(i);
            }
        });
    }
}
