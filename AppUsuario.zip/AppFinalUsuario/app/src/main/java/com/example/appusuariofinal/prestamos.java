package com.example.appusuariofinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class prestamos extends AppCompatActivity {

    private ImageButton todo,fotografia,sonido,pantallas,prestamodevolver, home, chat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prestamos);

        todo = findViewById(R.id.todoboton);
        fotografia = findViewById(R.id.fotoboton);
        sonido = findViewById(R.id.sonidoboton);
        pantallas = findViewById(R.id.pantallaboton);
        prestamodevolver = findViewById(R.id.prestamodevolver);
        chat = findViewById(R.id.chatprestamo);
        home = findViewById(R.id.homeboton);

        //BOTONES NAVEGACION LOCAL ARRIBA
        prestamodevolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),inicio.class);
                startActivity(i);
            }
        });

        todo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),prestamoTodos.class);
                startActivity(i);
            }
        });
        fotografia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),prestamoFotografia.class);
                startActivity(i);
            }
        });
        sonido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),prestamoSonido.class);
                startActivity(i);
            }
        });
        pantallas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),prestamoPantalla.class);
                startActivity(i);
            }
        });

        //BOTONES BARRA DE NAVEGACION ABAJO

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),inicio.class);
                startActivity(i);
            }
        });


        chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),chats.class);
                startActivity(i);
            }
        });
    }
}
