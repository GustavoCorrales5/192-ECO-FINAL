package com.example.appusuariofinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class inicio extends AppCompatActivity {

    private ImageButton chat,home,addPrestamo;
    private ImageButton prestamo,gestionar,ayuda;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);

        chat = findViewById(R.id.chatInicio);
        home = findViewById(R.id.homeInicio);
        addPrestamo = findViewById(R.id.userInicio);

        prestamo = findViewById(R.id.prestamoInicio);
        gestionar = findViewById(R.id.gestionarInicio);
        ayuda = findViewById(R.id.ayudaInicio);

        prestamo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),prestamos.class);
                startActivity(i);
            }
        });
        gestionar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),gestiones.class);
                startActivity(i);
            }
        });
        ayuda.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),ayudas.class);
                startActivity(i);
            }
        });

        //BOTONES BARRA DE NAVEGACION ABAJO


        chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),chats.class);
                startActivity(i);
            }
        });

        addPrestamo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),prestamos.class);
                startActivity(i);
            }
        });


    }
}
