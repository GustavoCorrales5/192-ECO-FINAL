package com.example.appusuariofinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class ayudaSonido extends AppCompatActivity {

    private ImageButton todo,fotografia,pantallas,ayudadevolver, home,chat,prestamo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ayuda_sonido);

        todo = findViewById(R.id.todoAyudaSonido);
        fotografia = findViewById(R.id.fotografiaAyudaSonido);
        pantallas = findViewById(R.id.pantallaAyudaSonido);
        ayudadevolver = findViewById(R.id.devolverSonido);

        chat = findViewById(R.id.chatAyudaSonido);
        prestamo = findViewById(R.id.userayudaSonido);
        home = findViewById(R.id.homeayudaSonido);

        //BOTONES NAVEGACION ABAJO

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),inicio.class);
                startActivity(i);
            }
        });
        prestamo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),prestamos.class);
                startActivity(i);
            }
        });
        chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),chats.class);
                startActivity(i);
            }
        });

        //BOTONES NAVEGACION ARRIBA

        ayudadevolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),inicio.class);
                startActivity(i);
            }
        });

        todo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),ayudas.class);
                startActivity(i);
            }
        });
        fotografia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),ayudaFotografia.class);
                startActivity(i);
            }
        });
        pantallas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),ayudaPantalla.class);
                startActivity(i);
            }
        });
    }
}
