package com.example.appusuariofinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

public class prestamoTodos extends AppCompatActivity {

    private ImageButton fotografia,sonido,pantallas,prestamodevolver, home, chat;
    private ImageButton addCam, addLuces, verElementos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prestamo_todos);

        fotografia = findViewById(R.id.fotoboton2);
        sonido = findViewById(R.id.sonidoboton2);
        pantallas = findViewById(R.id.pantallaboton2);
        prestamodevolver = findViewById(R.id.prestamodevolver2);
        chat = findViewById(R.id.chatprestamo2);
        home = findViewById(R.id.homeboton2);

        addCam = findViewById(R.id.addCamVid_Todo);
        addLuces = findViewById(R.id.addLuces_Todo);
        verElementos = findViewById(R.id.verelementos_Todo);

        //BOTON VER ELEMENTOS
        verElementos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        //BOTONES ANADIR COSAS
        addCam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "¡Elemento Añadido!", Toast.LENGTH_LONG).show();
            }
        });
        addLuces.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "¡Elemento Añadido!", Toast.LENGTH_LONG).show();
            }
        });

        //BOTONES NAVEGACION LOCAL ARRIBA
        prestamodevolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),inicio.class);
                startActivity(i);
            }
        });

        fotografia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),prestamoFotografia.class);
                startActivity(i);
            }
        });
        sonido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),prestamoSonido.class);
                startActivity(i);
            }
        });
        pantallas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),prestamoPantalla.class);
                startActivity(i);
            }
        });

        //BOTONES BARRA DE NAVEGACION ABAJO

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),inicio.class);
                startActivity(i);
            }
        });


        chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),chats.class);
                startActivity(i);
            }
        });
    }
}
