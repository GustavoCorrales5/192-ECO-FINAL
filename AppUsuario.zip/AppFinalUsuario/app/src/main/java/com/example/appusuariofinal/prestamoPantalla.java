package com.example.appusuariofinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

public class prestamoPantalla extends AppCompatActivity {

    private ImageButton todo,sonido,fotografia,prestamodevolver, home, chat;
    private ImageButton addTv, addProyector, verElementos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prestamo_pantalla);

        todo = findViewById(R.id.todoboton4);
        sonido = findViewById(R.id.sonidoboton4);
        fotografia = findViewById(R.id.pantallaboton4);
        prestamodevolver = findViewById(R.id.prestamodevolver4);
        chat = findViewById(R.id.chatprestamo4);
        home = findViewById(R.id.homeboton4);

        addTv = findViewById(R.id.addTv);
        addProyector = findViewById(R.id.addProyector);
        verElementos = findViewById(R.id.verelementos_Todo4);


        //BOTON VER ELEMENTOS
        /*verElementos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });*/

        //BOTONES ANADIR COSAS

        addTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "¡Elemento Añadido!", Toast.LENGTH_LONG).show();
            }
        });
        addProyector.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "¡Elemento Añadido!", Toast.LENGTH_LONG).show();
            }
        });

        //BOTONES NAVEGACION LOCAL ARRIBA
        prestamodevolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),inicio.class);
                startActivity(i);
            }
        });

        todo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),prestamoTodos.class);
                startActivity(i);
            }
        });
        sonido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),prestamoSonido.class);
                startActivity(i);
            }
        });
        fotografia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),prestamoFotografia.class);
                startActivity(i);
            }
        });

        //BOTONES BARRA DE NAVEGACION ABAJO

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),inicio.class);
                startActivity(i);
            }
        });


        chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),chats.class);
                startActivity(i);
            }
        });

    }
}
