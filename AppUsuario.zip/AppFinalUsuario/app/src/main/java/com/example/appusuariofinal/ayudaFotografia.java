package com.example.appusuariofinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class ayudaFotografia extends AppCompatActivity {

    private ImageButton todo,sonido,pantallas,ayudadevolver, home,chat,prestamo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ayuda_fotografia);

        todo = findViewById(R.id.todoAyudaFotografia);
        sonido = findViewById(R.id.sonidoAyudaFotografia);
        pantallas = findViewById(R.id.pantallaAyudaFotografia);
        ayudadevolver = findViewById(R.id.ayudadevolverFotografia);

        chat = findViewById(R.id.chatAyudaFotografia);
        prestamo = findViewById(R.id.userayudaFotografia);
        home = findViewById(R.id.homeayudaFotografia);

        //BOTONES NAVEGACION ABAJO

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),inicio.class);
                startActivity(i);
            }
        });
        prestamo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),prestamos.class);
                startActivity(i);
            }
        });
        chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),chats.class);
                startActivity(i);
            }
        });

        //BOTONES NAVEGACION ARRIBA

        ayudadevolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),inicio.class);
                startActivity(i);
            }
        });

        todo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),ayudas.class);
                startActivity(i);
            }
        });
        sonido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),ayudaSonido.class);
                startActivity(i);
            }
        });
        pantallas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),ayudaPantalla.class);
                startActivity(i);
            }
        });
    }
}
