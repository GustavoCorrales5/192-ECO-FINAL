package com.example.appusuariofinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

public class prestamoFotografia extends AppCompatActivity {

    private ImageButton todo,sonido,pantallas,prestamodevolver, home, chat;
    private ImageButton addLuces, verElementos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prestamo_fotografia);

        todo = findViewById(R.id.todoboton3);
        sonido = findViewById(R.id.sonidoboton3);
        pantallas = findViewById(R.id.pantallaboton3);
        prestamodevolver = findViewById(R.id.prestamodevolver3);
        chat = findViewById(R.id.chatprestamo3);
        home = findViewById(R.id.homeboton3);

        addLuces = findViewById(R.id.addLuces_Todo2);
        verElementos = findViewById(R.id.verelementos_Todo2);

        //BOTON VER ELEMENTOS
        /*verElementos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });*/

        //BOTONES ANADIR COSAS

        addLuces.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "¡Elemento Añadido!", Toast.LENGTH_LONG).show();
            }
        });

        //BOTONES NAVEGACION LOCAL ARRIBA
        prestamodevolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),inicio.class);
                startActivity(i);
            }
        });

        todo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),prestamoTodos.class);
                startActivity(i);
            }
        });
        sonido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),prestamoSonido.class);
                startActivity(i);
            }
        });
        pantallas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),prestamoPantalla.class);
                startActivity(i);
            }
        });

        //BOTONES BARRA DE NAVEGACION ABAJO

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),inicio.class);
                startActivity(i);
            }
        });


        chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),chats.class);
                startActivity(i);
            }
        });

    }
}
