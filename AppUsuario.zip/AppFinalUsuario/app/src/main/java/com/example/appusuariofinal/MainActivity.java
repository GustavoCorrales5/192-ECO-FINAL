package com.example.appusuariofinal;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {


    private Button boton;
    private EditText doc, contra;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference().child("users");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        boton = findViewById(R.id.botonMain);
        doc = findViewById(R.id.docMain);
        contra = findViewById(R.id.contrasenaMain);

        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*final String documento = doc.getText().toString();
                 final String contrase = contra.getText().toString();
                 final int contrasena = Integer.parseInt(contrase);
                 final DatabaseReference dbreference = database.getReference("users");*/
                Intent i = new Intent(getApplication(),inicio.class);
                startActivity(i);

                /* myRef.addValueEventListener(new ValueEventListener() {
                     @Override
                     public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                         if(myRef.child("ID").getKey().equals(documento)){



                             String pass = dataSnapshot.getValue(String.class);
                             doc.setText(pass);
                             int password = Integer.parseInt(pass);
                             if(pass == contrase){
                                 Intent i = new Intent(getApplication(),inicio.class);
                                 startActivity(i);
                             }else{
                                 Toast.makeText(MainActivity.this, "Contraseña Inválida", Toast.LENGTH_LONG).show();
                             }
                         }else {
                             Toast.makeText(MainActivity.this, "Código Inválido", Toast.LENGTH_LONG).show();

                         }
                     }

                     @Override
                     public void onCancelled(@NonNull DatabaseError databaseError) {

                     }
                 });*/
            /*    dbreference.child(documento).addValueEventListener(new ValueEventListener() {
                    @Override
                   public void onDataChange(DataSnapshot dataSnapshot) {
                      dbreference.child(contrase);
                        Intent i = new Intent(getApplication(),inicio.class);
                        startActivity(i);

                    }

                    @Override
                    public void onCancelled(DatabaseError error) {
                        // Failed to read value
                    }
                });
*/
            }
        });





    }

}
