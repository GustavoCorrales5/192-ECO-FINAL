package com.example.appusuariofinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class gestiones extends AppCompatActivity {

    private ImageButton gestionardevolver, home;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gestiones);

        gestionardevolver = findViewById(R.id.gestionardevolver);

        home = findViewById(R.id.homegestionar);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),inicio.class);
                startActivity(i);
            }
        });

        gestionardevolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),inicio.class);
                startActivity(i);
            }
        });
    }
}
