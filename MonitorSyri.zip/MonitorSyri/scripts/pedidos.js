var diasSemana=[];
var listaPedidos=document.querySelector('.pedidos__list');

diasSemana.push("lunes");
diasSemana.push("martes");
diasSemana.push("miercoles");
diasSemana.push("jueves");
diasSemana.push("viernes");
diasSemana.push("sabado");


for(var i=0;i<diasSemana.length;i++){
    var ref=firebase.database().ref('pedidos/'+diasSemana[i]);
    
    ref.on("child_added", function(snapshot){

        console.log("El juego actual es ", snapshot.val());
        var data=snapshot.val();
        
        
        
        let listItem = document.createElement("div");
        listItem.id=data.ID;
        listItem.innerHTML =
        "<div class=\"list__item\">"+
        ""+"<div class=\"tamfecha\"><h4>"+data.fecha+"</h4></div><br><div class=\"tamhoraini\"><h4>Hora de inicio: "+data.horaInicio+"</h4></div><br>"+
        "<div class=\"tamhoraini\">"+"<h4>Hora de termino: "+data.horaFinal+"</h4></div><br>"+
        ""+"<div>"+"Elementos requeridos: "+data.elementos+"</div>"+"<br>"+
        ""+ "</div>";
        listaPedidos.appendChild(listItem);    
    });
}

var inicio=document.querySelector('.nav__user');

inicio.addEventListener("click",function(event){
    window.location.href = '/views/home.html';
})





